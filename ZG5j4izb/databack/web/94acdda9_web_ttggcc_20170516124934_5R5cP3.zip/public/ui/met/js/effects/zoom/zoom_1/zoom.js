define('',[
'effects/zoom/zoom_1/img/metinfo.css',
'effects/zoom/zoom_1/common',
'effects/zoom/zoom_1/forum_viewthread'
],function(require, exports, module) {});
