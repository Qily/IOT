<!--<?php
require_once template('head'); 
require_once template('sidebar');
echo <<<EOT
-->
        <div class="met_editor met_module1">
		    {$show[content]}
			<div class="clear"></div>
		</div>
<!--
EOT;
require_once template('gap');
require_once template('foot');
?>