<!--<?php
echo <<<EOT
-->
	</div>
    </article>
    <div class="met_clear"></div>
</section>
<!--
EOT;
?>